# hbox-fax

Usage guide for the project that consumes this package.

This package gives you two browser-side integration options:

- Open a received fax modal directly from your app.
- Render the package-owned fax UI inside a container.

`HBoxFax.init(...)` accepts either an existing element, an element id like `fax-container`, or a selector like `#fax-container`. If a string target does not match anything yet, the package creates a container and appends it to `document.body`.

## Install

If this package is published or linked into your app:

```bash
npm install hbox-fax
```

If you are using it locally from this workspace, build the package first so `dist/` exists:

```bash
npm install
npm run build
```

## Required Assets

Your consumer project must load the package CSS.

Bundler-based app:

```ts
import 'hbox-fax/dist/hbox-fax.css';
import HBoxFax from 'hbox-fax';
```

Plain HTML usage:

```html
<link rel="stylesheet" href="dist/hbox-fax.css">
<script src="dist/hbox-fax.umd.js"></script>
```

## Fastest Integration: Open the Modal Directly

Use this when your app already has fax data and just needs the package-owned modal.

```ts
import HBoxFax, { FaxStatus, FaxUserRole } from 'hbox-fax';
import 'hbox-fax/dist/hbox-fax.css';

function openFaxPreview(): void {
  HBoxFax.openReceivedFaxModal(
    { theme: 'light' },
    {
      fax: {
        faxId: 'fax-001',
        sender: {
          faxNumber: '+1-555-0100',
          displayName: 'Downtown Cardiology',
        },
        recipient: {
          faxNumber: '+1-555-0199',
          displayName: 'NGPEP Intake',
        },
        inbox: {
          inboxId: 'main-inbox',
          inboxName: 'Main Fax Inbox',
          faxNumber: '+1-555-0199',
        },
        receivedAt: new Date(),
        pageCount: 3,
        status: FaxStatus.NEW,
        previewSource: {
          kind: 'pdf-url',
          url: '/received-faxes/sample-fax.pdf',
          fileName: 'sample-fax.pdf',
        },
      },
      onMarkAsRead: async ({ fax, controller }) => {
        console.log('Mark as read', fax.faxId);
        controller.close();
      },
      onDownload: async ({ fax }) => {
        console.log('Download', fax.faxId);
      },
    },
  );
}
```

## Render the Fax UI in a Container

Use this when you want the package to render its own fax shell with `New Fax` and the dedicated `History` module.

HTML:

```html
<div id="fax-container"></div>
```

TypeScript:

```ts
import HBoxFax, { FaxStatus } from 'hbox-fax';
import 'hbox-fax/dist/hbox-fax.css';

const faxManager = HBoxFax.init('fax-container', {
  theme: 'light',
  profile: {
    type: 'EA',
  },
  initialNewFaxes: [
    {
      faxId: 'fax-001',
      sender: {
        faxNumber: '+1-555-0100',
        displayName: 'Downtown Cardiology',
      },
      inbox: {
        inboxName: 'Main Fax Inbox',
        faxNumber: '+1-555-0199',
      },
      receivedAt: new Date(),
      pageCount: 3,
      status: FaxStatus.NEW,
      previewSource: {
        kind: 'pdf-url',
        url: '/received-faxes/sample-fax.pdf',
      },
    },
  ],
  initialHistoryFaxes: [
    {
      faxId: 'fax-000',
      sender: {
        faxNumber: '+1-555-0108',
        displayName: 'North Clinic',
      },
      inbox: {
        inboxName: 'Archive Inbox',
        faxNumber: '+1-555-0188',
      },
      receivedAt: new Date(Date.now() - 86400000),
      pageCount: 2,
      status: FaxStatus.ARCHIVED,
      previewSource: {
        kind: 'image-url',
        url: '/received-faxes/page-1.png',
      },
    },
  ],
  onFaxMarkedAsRead: async fax => {
    console.log('Moved to history', fax.faxId);
  },
});

faxManager.setTheme('dark');
faxManager.refresh();
// faxManager.destroy();
```

## Config Reference

`HBoxFax.init(containerTarget, config)` and `HBoxFax.openReceivedFaxModal(config, options)` support these main config values:

- `theme`: `'light' | 'dark'`
- `hideTabs`: hide `new` or `history` when using the container UI
- `profile`: RBAC context for the container UI; use `type: 'EA'` to show both `Inbound Fax` and `History`, or `type: 'ES'` to hide `History`
- `actor`: legacy role-aware user context; if `profile` is not provided, `history` remains visible only for `ENROLL_ADMIN`
- `initialNewFaxes`: items shown in the `New Fax` tab
- `initialHistoryFaxes`: items shown in the `History` tab
- `initialHistoryRows`: richer history rows used by the dedicated history table
- `historyPageSize`: items per page in the history table
- `onFaxMarkedAsRead`: callback fired when an item is marked as read from the package UI

## Fax Data Shape

Minimum useful fax payload:

```ts
{
  faxId: 'fax-001',
  sender: {
    faxNumber: '+1-555-0100',
  },
  receivedAt: new Date(),
  previewSource: {
    kind: 'pdf-url',
    url: '/received-faxes/sample-fax.pdf',
  },
}
```

Supported `previewSource.kind` values:

- `pdf-url`
- `image-url`
- `blob-url`
- `document-url`

Optional fields that improve the UI:

- `sender.displayName`
- `recipient`
- `inbox`
- `pageCount`
- `status`
- `previewSource.fileName`
- `previewSource.title`

## Plain JavaScript Example

```html
<link rel="stylesheet" href="dist/hbox-fax.css">
<script src="dist/hbox-fax.umd.js"></script>

<button id="openFax">Open Fax</button>

<script>
  document.getElementById('openFax').addEventListener('click', function () {
    HBoxFax.openReceivedFaxModal(
      { theme: 'light' },
      {
        fax: {
          faxId: 'fax-001',
          sender: { faxNumber: '+1-555-0100', displayName: 'Downtown Cardiology' },
          receivedAt: new Date().toISOString(),
          previewSource: {
            kind: 'pdf-url',
            url: '/received-faxes/sample-fax.pdf'
          }
        }
      }
    );
  });
</script>
```

## Notes for the Consuming Project

- The package CSS is required. Without it, the UI will render unstyled.
- Bootstrap styles are scoped under `.hbox-hx-fax-wrapper-area`, so they do not leak into the rest of your app.
- The modal API is the best option if your app already owns the fax list and just wants package UI for preview.
- The container API is the best option if you want the package to render the list shell and modal together.
- If you do not pass any fax arrays to `init(...)`, the package renders an empty shell until data is loaded or supplied.
- The backend workflow methods on `HBoxFax` are still placeholders. The usable consumer-facing browser APIs are `init(...)`, `openReceivedFaxModal(...)`, and `showReceivedFaxModal(...)`.
