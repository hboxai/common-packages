# @hbox/sms - SMS Management Package

A framework-agnostic, memory-leak-free SMS management package with Bootstrap UI, dark mode support, and comprehensive filtering capabilities.

## Features

- ✅ **Framework Agnostic** - Works with Angular, React, Vue, or vanilla JavaScript
- ✅ **Memory Leak Free** - Proper cleanup and resource management
- ✅ **Dark Mode Compatible** - Seamless light/dark theme switching
- ✅ **Custom Bootstrap Prefix** - Uses `hx-sms-` prefix to prevent conflicts
- ✅ **Three Main Tabs**:
  - **Inbound SMS** - View and manage unread messages
  - **SMS Campaign** - Create and track SMS campaigns
  - **History** - Complete SMS history with advanced filters
- ✅ **Advanced Filtering** - Search by patient, clinic, date range, and more
- ✅ **Pagination** - Efficient data loading with customizable page sizes
- ✅ **TypeScript Support** - Full type definitions included

## Installation

```bash
npm install @hbox/sms
```

## Quick Start

### 1. HTML Setup

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SMS Management</title>
  
  <!-- Include the package CSS -->
  <link rel="stylesheet" href="node_modules/@hbox/sms/dist/hbox-sms.css">
</head>
<body>
  <!-- Container for SMS Manager -->
  <div id="sms-container"></div>
  
  <!-- Include the package JS -->
  <script src="node_modules/@hbox/sms/dist/hbox-sms.js"></script>
  
  <script>
    // Initialize SMS Manager
    const smsManager = HBoxSMS.init('sms-container', {
      theme: 'light', // or 'dark'
      loggedInUserId: 192609,
      apiBaseUrl: 'https://api.example.com',
      graphqlBaseUrl: 'https://graphql.example.com',
      apiToken: 'your-api-token',
      graphqlToken: 'your-graphql-token',
      key: 'PEP' // Optional, defaults to 'PEP'
    });
  </script>
</body>
</html>
```

### 2. Framework Integration

#### React Example

```jsx
import { useEffect, useRef } from 'react';
import HBoxSMS from '@hbox/sms';
import '@hbox/sms/dist/hbox-sms.css';

function SMSComponent() {
  const containerRef = useRef(null);
  const managerRef = useRef(null);
  
  useEffect(() => {
    if (containerRef.current && !managerRef.current) {
      managerRef.current = HBoxSMS.init('sms-container', {
        theme: 'light',
        loggedInUserId: 192609,
        apiBaseUrl: process.env.REACT_APP_API_URL,
        graphqlBaseUrl: process.env.REACT_APP_GRAPHQL_URL,
        apiToken: process.env.REACT_APP_API_TOKEN,
        graphqlToken: process.env.REACT_APP_GRAPHQL_TOKEN
      });
    }
    
    // Cleanup on unmount
    return () => {
      if (managerRef.current) {
        managerRef.current.destroy();
        managerRef.current = null;
      }
    };
  }, []);
  
  return <div id="sms-container" ref={containerRef} />;
}

export default SMSComponent;
```

#### Angular Example

```typescript
import { Component, OnInit, OnDestroy } from '@angular/core';
import HBoxSMS from '@hbox/sms';
import '@hbox/sms/dist/hbox-sms.css';

@Component({
  selector: 'app-sms',
  template: '<div id="sms-container"></div>'
})
export class SmsComponent implements OnInit, OnDestroy {
  private smsManager: any;
  
  ngOnInit() {
    this.smsManager = HBoxSMS.init('sms-container', {
      theme: 'light',
      loggedInUserId: 192609,
      apiBaseUrl: environment.apiUrl,
      graphqlBaseUrl: environment.graphqlUrl,
      apiToken: environment.apiToken,
      graphqlToken: environment.graphqlToken
    });
  }
  
  ngOnDestroy() {
    if (this.smsManager) {
      this.smsManager.destroy();
    }
  }
}
```

## Configuration

### SMSConfig Interface

```typescript
interface SMSConfig {
  theme?: 'light' | 'dark';        // Theme mode (default: 'light')
  loggedInUserId: number;          // ID of the logged-in user
  apiBaseUrl: string;              // Base URL for REST API
  graphqlBaseUrl: string;          // Base URL for GraphQL API
  apiToken: string;                // JWT token for REST API
  graphqlToken: string;            // JWT token for GraphQL API
  key?: string;                    // Application key (default: 'PEP')
}
```

## API Methods

### Initialize

```javascript
const smsManager = HBoxSMS.init(containerId, config);
```

### Set Theme

```javascript
smsManager.setTheme('dark'); // or 'light'
```

### Refresh Current Tab

```javascript
await smsManager.refresh();
```

### Destroy

```javascript
smsManager.destroy(); // Clean up resources
```

## Features Overview

### Inbound SMS Tab

- View all unread SMS messages
- Filter by patient name, clinic name, phone numbers, message content, and date range
- Mark messages as read
- Real-time unread count badge
- Pagination with customizable page size

### SMS Campaign Tab

- View all SMS campaigns with delivery status
- Create new campaigns with:
  - Campaign name
  - SMS template selection with preview
  - Patient group selection
  - From number selection (auto-populated based on clinic)
  - CCM/RPM status filters
- Filter campaigns by name, template, patient group, and date range
- Track delivery success/failure counts

### History Tab

- Complete SMS history (inbound and outbound)
- Advanced filtering:
  - Patient details
  - Clinic information
  - Sender name
  - Message content
  - Campaign name
  - Direction (Inbound/Outbound)
  - Status (Sent/Delivered/Failed)
  - Date range
- Detailed information display

## Query Parameters

The active tab is automatically saved to URL query parameters:

```
?tab=inbound   // Inbound SMS tab
?tab=campaign  // SMS Campaign tab
?tab=history   // History tab
```

This allows for:
- Bookmarking specific tabs
- Deep linking
- Browser back/forward navigation
- Page refresh persistence

## Dark Mode

The package supports dark mode out of the box. Simply set the theme in config:

```javascript
HBoxSMS.init('sms-container', {
  theme: 'dark',
  // ... other config
});
```

Or change it dynamically:

```javascript
smsManager.setTheme('dark');
```

## Custom Bootstrap Prefix

All Bootstrap classes use the `hx-sms-` prefix to prevent conflicts with other Bootstrap instances or UI libraries:

```
hx-sms-btn
hx-sms-table
hx-sms-modal
hx-sms-form-control
// etc.
```

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## Performance

- Optimized for large datasets with pagination
- Debounced search inputs
- Lazy loading of dropdown options
- Efficient DOM manipulation
- No memory leaks with proper cleanup

## TypeScript

Full TypeScript support with type definitions included:

```typescript
import HBoxSMS, { SMSConfig, SMSManager } from '@hbox/sms';

const config: SMSConfig = {
  theme: 'light',
  loggedInUserId: 192609,
  apiBaseUrl: 'https://api.example.com',
  graphqlBaseUrl: 'https://graphql.example.com',
  apiToken: 'token',
  graphqlToken: 'token'
};

const manager: SMSManager = HBoxSMS.init('container', config);
```

## License

MIT

## Support

For issues and feature requests, please contact the HBox development team.
