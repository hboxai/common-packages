# HBox-Call

A framework-agnostic package for handling calls using Twilio Voice SDK. This package is designed for healthcare applications and can be used with any JavaScript framework, including Angular and React.

## Features

- Framework-agnostic implementation
- Responsive design
- Easy integration with Twilio Voice SDK
- Comprehensive call management
- Event-based architecture
- TypeScript support
- Patient/Clinic number selection modal
- Automatic token refresh
- Call duration tracking
- Standalone CSS that can be imported directly

## Installation

```bash
npm install hbox-call
```

**Note**: 
- The package includes a **scoped version of Bootstrap** (wrapped in `.hbox-call-bootstrap` class) to avoid conflicts with your parent application's Bootstrap.
- The dialer modal uses `multiple-select-vanilla` (v4.3.10) for the searchable dropdown.

## Usage

### Importing Styles

The package provides CSS styles that can be imported in different ways depending on your framework:

#### Direct CSS Import

You can import the CSS directly in your main CSS file:

```css
@import '~hbox-call/dist/ui/styles.css';
```

#### Angular

In your `angular.json` file, add the CSS to the styles array:

```json
{
  "projects": {
    "your-app": {
      "architect": {
        "build": {
          "options": {
            "styles": [
              "node_modules/hbox-call/dist/ui/styles.css"
            ]
          }
        }
      }
    }
  }
}
```

#### React

In your main component or index.js file:

```javascript
import 'hbox-call/dist/ui/styles.css';
```



### Initializing the Package

```javascript
import { HBoxCall } from 'hbox-call';

// Create an instance of HBoxCall
const hboxCall = new HBoxCall();

// Initialize the device with a token endpoint URL
await hboxCall.initializeDevice(
  // Token endpoint URL
  'https://your-backend.com/api/twilio-token',
  // User identifier (e.g., email)
  'user@example.com',
  // Device options
  {
    allowIncomingWhileBusy: false,
    closeProtection: true,
    enableImprovedSignalingErrorPrecision: true,
    logLevel: 4,
    maxCallSignalingTimeoutMs: 5000,
  },
  // Optional authorization token for API requests
  'your-auth-token-here' // e.g., JWT token from your authentication system
);
```

### Making a Call

```javascript
// Make an outgoing call
try {
  const callParams = {
    To: '+15551234567',           // Destination phone number
    From: '+18001234567',         // Outbound clinic number
    PatientId: 'P12345',          // Patient identifier
    CallerId: 'Dr. Johnson',      // Caller ID
    HccId: 'HCC001',              // Healthcare center ID
    Timezone: 'America/New_York', // Patient timezone
    PatientName: 'John Smith',    // Patient name
    ClinicName: 'Main Street Clinic', // Clinic name
    NumberType: 'primary'         // Type of number being called
  };
  
  const callInfo = await hboxCall.makeCall(callParams);
  console.log('Call connected!', callInfo);
} catch (error) {
  console.error('Failed to make call:', error);
}
```

### Handling Call Events

```javascript
// Add call event listeners
hboxCall.addCallEventListeners({
  onStatusChanged: (status) => {
    console.log('Call status changed:', status);
  },
  onMuteChanged: (isMuted) => {
    console.log('Call mute status:', isMuted ? 'muted' : 'unmuted');
  },
  onDurationChanged: (duration) => {
    console.log('Call duration:', duration, 'seconds');
  },
  onError: (error) => {
    console.error('Call error:', error);
  },
});
```

### Handling Device Events

```javascript
// Add device event listeners
hboxCall.addDeviceEventListeners({
  onReady: () => {
    console.log('Device is ready to make calls');
  },
  onError: (error) => {
    console.error('Device error:', error);
  },
  onIncoming: (call) => {
    console.log('Incoming call from:', call.parameters.From);
    // Auto-accept the call
    call.accept();
  },
  onDisconnect: () => {
    console.log('Device disconnected');
  },
});
```

### Managing Calls

```javascript
// End the current call
hboxCall.endCall();

// Mute/unmute the call
hboxCall.muteCall();   // Mute
hboxCall.unmuteCall(); // Unmute

// Get current call information
const callInfo = hboxCall.getCallInfo();
console.log('Current call:', callInfo);

// Check if device is ready
const isReady = hboxCall.isDeviceReady();
console.log('Device ready:', isReady);

// Clean up resources when done
hboxCall.destroy();
```

### Using the Number Selection Modal

```javascript
// Show the number selection modal
const modalOptions = {
  // Patient information
  patientId: 'P12345',
  patientName: 'John Smith',
  primaryPhone: '+15551234567',
  alternatePhone: '+15559876543',
  emergencyPhone: '+15551112222',
  emergencyContactName: 'Jane Smith',
  
  // Clinic information
  callerId: 'Dr. Johnson',
  hccId: 'HCC001',
  clinicName: 'Main Street Clinic',
  timezone: 'America/New_York',
  clinicNumbers: ['+18001234567', '+18009876543'],
  clinicNumbersSources: ['Main Office', 'Branch Office'],
  
  // Callbacks
  onCallInitiated: (params) => {
    console.log('Call initiated with params:', params);
    // params contains phoneNumber, clinicNumber, patientId, etc.
  },
  onCancel: () => {
    console.log('Call modal cancelled');
  }
};

// Show the modal
hboxCall.showNumberSelectionModal(modalOptions);
```

### Using the Dialer Modal

The Dialer Modal provides a beautiful interface for making outbound calls with:
- Searchable "from" number selection with source filtering
- Interactive dialpad for entering destination numbers
- Keyboard support for number entry
- Real-time validation and formatting

```javascript
// Example numbers data from your API
const numbers = [
  {
    "phone_number": "7206398544",
    "number_source_id": 3,
    "incoming_call_type": "call",
    "is_active": true,
    "is_deleted": false,
    "is_global": false,
    "origin_number_type_id": 3
  },
  {
    "phone_number": "7205551234",
    "number_source_id": 1,
    "incoming_call_type": "call",
    "is_active": true,
    "is_deleted": false
  }
];

// Number sources for filtering and display
const numberSources = [
  {
    "number_source_id": 1,
    "number_source": "Twilio",
    "is_deleted": false
  },
  {
    "number_source_id": 2,
    "number_source": "Ported",
    "is_deleted": false
  },
  {
    "number_source_id": 3,
    "number_source": "Clinic",
    "is_deleted": false
  }
];

// Configure and show the dialer modal
const dialerOptions = {
  numbers: numbers,
  numberSources: numberSources,
  
  // Optional: Add call metadata
  patientName: 'John Doe',
  patientId: 456,
  callerId: 123,
  hccId: 789,
  clinicName: 'Main Clinic',
  timezone: 'America/Denver',
  
  // Optional: Callbacks
  onCallInitiated: (params) => {
    console.log('Call initiated:', params);
    // params: { from, to, patientName, patientId, callerId, hccId, clinicName, timezone }
  },
  onCancel: () => {
    console.log('Dialer cancelled');
  }
};

hboxCall.showDialerModal(dialerOptions);
```

#### Dialer Modal Features

- **From Number Selection (using multiple-select-vanilla v4.3.10)**
  - Source filter dropdown to filter by number source (All, Twilio, Ported, Clinic, etc.)
  - Searchable dropdown with search inside dropdown itself
  - Grouped by number source
  - Source displayed in gray text after each number
  - Clean, professional dropdown UI
  - Real-time search filtering

- **To Number Input**
  - Input field for typing phone numbers
  - Interactive dialpad for clicking numbers (1-9, 0, *, #)
  - Backspace button for corrections
  - Auto-filters to allow only valid characters (0-9, *, +, #)
  - Both keyboard typing and dialpad clicking work
  - Press Enter to initiate call
  - Focus state with blue highlight
  - Visual feedback on dialpad button press

- **Validation & Error Handling**
  - Call button disabled until both from and to numbers are valid
  - Filters inactive/deleted numbers automatically
  - Validates phone number length (min 10 digits)
  - Prevents calls when another call is active
  - Shows toast notification for active calls
  - Graceful error handling with user-friendly alerts

## API Reference

### HBoxCall Class

#### Methods

- `initializeDevice(tokenEndpoint, identifier, options, authToken)`: Initialize the Twilio device with a token endpoint URL and optional authorization token
- `makeCall(params)`: Make an outgoing call with comprehensive call parameters
- `endCall()`: End the current call
- `muteCall()`: Mute the current call
- `unmuteCall()`: Unmute the current call
- `getCallInfo()`: Get current call information
- `showNumberSelectionModal(options)`: Show the number selection modal for patient calls
- `showDialerModal(options)`: Show the dialer modal with searchable number selection and dialpad
- `addCallEventListeners(listeners)`: Add event listeners for call events
- `addDeviceEventListeners(listeners)`: Add event listeners for device events
- `isDeviceReady()`: Check if the device is ready to make calls
- `destroy()`: Destroy the device and clean up resources

### NumberSelectionModal Class

#### Methods

- `constructor(options)`: Create a new modal instance with the provided options
- `show()`: Display the modal
- `hide()`: Hide the modal

#### Options

- `patientId`: Patient identifier
- `patientName`: Patient name
- `primaryPhone`: Patient's primary phone number
- `alternatePhone`: Patient's alternate phone number (optional)
- `emergencyPhone`: Patient's emergency contact phone number (optional)
- `emergencyContactName`: Name of the emergency contact (optional)
- `callerId`: Caller ID for outbound calls
- `hccId`: Healthcare center ID
- `clinicName`: Name of the clinic
- `timezone`: Patient's timezone
- `clinicNumbers`: Array of available clinic numbers for outbound calls
- `clinicNumbersSources`: Array of sources/descriptions for clinic numbers
- `onCallInitiated`: Callback function when a call is initiated
- `onCancel`: Callback function when the modal is cancelled

### DialerModal Class

#### Methods

- `constructor(options, hboxCallInstance)`: Create a new dialer modal instance
- `show()`: Display the modal
- `close()`: Close the modal

#### Options

- `numbers`: Array of phone number objects with the following structure:
  - `phone_number`: The phone number string
  - `number_source_id`: ID linking to number source
  - `is_active`: Whether the number is active (optional, defaults to true)
  - `is_deleted`: Whether the number is deleted (optional, defaults to false)
  - `incoming_call_type`: Type of incoming call (optional)
  - `is_global`: Whether number is global (optional)
  - `origin_number_type_id`: Origin number type ID (optional)

- `numberSources`: Array of number source objects:
  - `number_source_id`: Unique identifier for the source
  - `number_source`: Display name (e.g., "Twilio", "Ported", "Clinic")
  - `is_deleted`: Whether the source is deleted (optional)

- `patientName`: Patient name for call metadata (optional)
- `patientId`: Patient ID (optional)
- `callerId`: Caller ID (optional)
- `hccId`: Healthcare center ID (optional)
- `clinicName`: Clinic name (optional)
- `timezone`: Timezone for the call (optional)
- `onCallInitiated`: Callback function when a call is initiated with params: `{ from, to, patientName, patientId, callerId, hccId, clinicName, timezone }`
- `onCancel`: Callback function when the modal is cancelled

## License

MIT
